package com.example.Minesweeper.Logic;

public class Record {
    public String name;
    public int clickCounter;
    public int time;
}
